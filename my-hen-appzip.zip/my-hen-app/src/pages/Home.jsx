import React, { useEffect, useState } from "react";
import VerticalCardSection from "../components/VerticalCardSection";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [goats, setGoats] = useState([]);
  const [buffaloes, setBuffaloes] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [punjuRes, goatRes, buffaloRes] = await Promise.all([
          fetch("http://localhost:3001/punjus"),
          fetch("http://localhost:3001/goat"),
          fetch("http://localhost:3001/buffalo"),
        ]);

        if (!punjuRes.ok || !goatRes.ok || !buffaloRes.ok) {
          throw new Error("One or more fetches failed");
        }

        const [punjuData, goatData, buffaloData] = await Promise.all([
          punjuRes.json(),
          goatRes.json(),
          buffaloRes.json(),
        ]);

        const processedPunju = punjuData.map((item) => ({
          ...item,
          type: "punju",
          image: item.image?.startsWith("http") ? item.image : `http://localhost:3001${item.image}`,
        }));

        const processedGoat = goatData.map((item) => ({
          ...item,
          type: "goat",
          image: item.image?.startsWith("http") ? item.image : `http://localhost:3001${item.image}`,
        }));

        const processedBuffalo = buffaloData.map((item) => ({
          ...item,
          type: "buffalo",
          image: item.image?.startsWith("http") ? item.image : `http://localhost:3001${item.image}`,
        }));

        setProducts(processedPunju);
        setGoats(processedGoat);
        setBuffaloes(processedBuffalo);
        setError("");
      } catch (err) {
        console.error("❌ Error fetching data:", err);
        setError("Failed to load product data.");
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <VerticalCardSection
        title="Punju 🐓"
        linkTo="/punjus"
        products={products}
        type="punju"
      />
      <VerticalCardSection
        title="Buffaloes 🐃"
        linkTo="/buffalo"
        products={buffaloes}
        type="buffalo"
      />

      <VerticalCardSection
        title="Goats 🐐"
        linkTo="/goat"
        products={goats}
        type="goat"
      />

      {error && <p className="text-red-500 mt-4 text-center">{error}</p>}
    </div>
  );
}
